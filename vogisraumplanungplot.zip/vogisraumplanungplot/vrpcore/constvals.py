# -*- coding: utf-8 -*-

DLG_CAPTION = 'VoGIS Raumplanung Plot'
VRP_DEBUG = False
